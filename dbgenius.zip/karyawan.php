<?php
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>COUNTER Admin - Blank Page</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="index.html">ADMIN COUNTER</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

      <!-- Navbar Search -->
      <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Pencarian..." aria-label="Search" aria-describedby="basic-addon2">
          <div class="input-group-append">
            <button class="btn btn-primary" type="button">
              <i class="fas fa-search"></i>
            </button>
          </div>
        </div>
      </form>

      <!-- Navbar -->
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle fa-fw"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="/updatekaryawan.php">Edit Profil</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="/login.html" data-toggle="modal" data-target="#logoutModal">Logout</a>
          </div>
        </li>
      </ul>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="utama.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="inputbarang.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Input Barang</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="jualbarang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Jual Barang</span></a>
        </li>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="kirimpesan.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Kirim Pesan</span></a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Laporan</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Laporan Counter</h6>
            <a class="dropdown-item" href="laporan.php">Laporan Margin</a>
            <a class="dropdown-item" href="stok.php">Produk Tersisa</a>
            <a class="dropdown-item" href="terjual.php">Produk Terjual</a>
            <div class="dropdown-divider"></div>
          </div>
        </li>
        <div class="dropdown-divider"></div>
        <li class="nav-item">
          <a class="nav-link" href="karyawan.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Karyawan</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="pesan.php">
            <i class="fas sign-out-alt"></i>
            <span>Pesan</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/login.html" data-toggle="modal" data-target="#logoutModal">
            <i class="fas sign-out-alt"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Karyawan</li>
          </ol>

          <!-- Page Content -->
          <div class="row">
            <div class="col-sm-9"></div>
            <!-- Large modal -->
            <div class="col-sm-3">
              <button type="button" class="btn btn-success btn-block mb-3" data-toggle="modal" data-target="#ModalTambahKaryawan">Tambah Karyawan</button>
            </div>
          </div>

        <!-- Modal Tambah Karyawan -->
        <div class="modal fade" id="ModalTambahKaryawan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><b>Tambah Karyawan</b></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" action="karyawan.php">
                  <div class="form-row">
                    <div class="col-md-8 mb-3">
                      <label for="validationDefault01">Nama Lengkap</label>
                      <input type="text" name="nama" class="form-control" id="validationDefault01" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefaultUsername">Username</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="inputGroupPrepend2">@</span>
                        </div>
                        <input type="text" name="username" class="form-control" id="validationDefaultUsername" placeholder="Username" aria-describedby="inputGroupPrepend2" required>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="exampleFormControlSelect1">Status Sebagai</label>
                    <select class="form-control" id="exampleFormControlSelect1" name="status">
                      <option>Admin</option>
                      <option>Karyawan</option>
                    </select>
                  </div>
                  <div class="form-row">
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault03">Tanggal Lahir</label>
                      <input type="date" name="ttl" class="form-control" id="validationDefault03" placeholder="00-00-0000" required>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault04">Jenis Kelamin</label>
                        <select name="kelamin" class="custom-select mr-sm-2" id="inlineFormCustomSelect" required>
                          <option selected>Pilih...</option>
                          <option value="1">Laki-Laki</option>
                          <option value="0">Perempuan</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault05">Telepon</label>
                      <input type="text" name="telepon" class="form-control" id="validationDefault05" placeholder="Telepon" required>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="col-md-12">
                      <label for="validationDefault06">Alamat</label>
                      <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="2" required></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="form-row">
                      <div class="col-md-6">
                        <label for="inputPassword">Password</label>
                        <div class="form-label-group">
                          <input type="password" id="inputPassword" class="form-control" placeholder="Password" required="required" name="password">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <label for="confirmPassword">Konfirmasi Password</label>
                        <div class="form-label-group">
                          <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm password" required="required" name="password">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                      <label class="form-check-label" for="invalidCheck2">
                        Agree to terms and conditions
                      </label>
                    </div>
                  </div>
                  <button name="update" class="btn btn-success" type="submit">Simpan</button>
                </form>
              </div>
            </div>
          </div>
        </div>

          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Data Karyawan</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Username</th>
                      <th>Nama</th>
                      <th>Status</th>
                      <th>TTL</th>
                      <th>Kelamin</th>
                      <th>Telepon</th>
                      <th>Alamat</th>
                      <th>Password</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Username</th>
                      <th>Nama</th>
                      <th>Status</th>
                      <th>TTL</th>
                      <th>Kelamin</th>
                      <th>Telepon</th>
                      <th>Alamat</th>
                      <th>Password</th>
                      <th>Akasi</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    <tr>
                      <td>fauza</td>
                      <td>Ahmad Fauza Aulia</td>
                      <td>Admin</td>
                      <td>20-04-1999</td>
                      <td>L</td>
                      <td>081215212066</td>
                      <td>Semarang Tembalang Kono Adoh</td>
                      <td>rahasia</td>
                      <td>
                        <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalEditKaryawan">Edit</button>
                          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#ModalHapusDataKaryawan">Hapus</button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

       <!-- Modal Edit Karyawan -->
        <div class="modal fade" id="ModalEditKaryawan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><b>Edit Karyawan</b></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" action="karyawan.php">
                  <div class="form-row">
                    <div class="col-md-8 mb-3">
                      <label for="validationDefault01">Nama Lengkap</label>
                      <input type="text" name="nama" class="form-control" id="validationDefault01" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefaultUsername">Username</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="inputGroupPrepend2">@</span>
                        </div>
                        <input type="text" name="username" class="form-control" id="validationDefaultUsername" placeholder="Username" aria-describedby="inputGroupPrepend2" required>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="exampleFormControlSelect1">Status Sebagai</label>
                    <select class="form-control" id="exampleFormControlSelect1" name="status">
                      <option>Admin</option>
                      <option>Karyawan</option>
                    </select>
                  </div>
                  <div class="form-row">
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault03">Tanggal Lahir</label>
                      <input type="date" name="ttl" class="form-control" id="validationDefault03" placeholder="00-00-0000" required>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault04">Jenis Kelamin</label>
                        <select name="kelamin" class="custom-select mr-sm-2" id="inlineFormCustomSelect" required>
                          <option selected>Pilih...</option>
                          <option value="1">Laki-Laki</option>
                          <option value="0">Perempuan</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                      <label for="validationDefault05">Telepon</label>
                      <input type="text" name="telepon" class="form-control" id="validationDefault05" placeholder="Telepon" required>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="col-md-12">
                      <label for="validationDefault06">Alamat</label>
                      <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="2" required></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="form-row">
                      <div class="col-md-6">
                        <label for="inputPassword">Password</label>
                        <div class="form-label-group">
                          <input type="password" id="inputPassword" class="form-control" placeholder="Password" required="required" name="password">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <label for="confirmPassword">Konfirmasi Password</label>
                        <div class="form-label-group">
                          <input type="password" id="confirmPassword" class="form-control" placeholder="Confirm password" required="required" name="password">
                        </div>
                      </div>
                    </div>
                  </div>
                  <button name="update" class="btn btn-success" type="submit">Simpan</button>
                </form>
              </div>
            </div>
          </div>
        </div>

       <!-- Modal Hapus Karyawan -->
       <div class="modal fade" id="ModalHapusDataKaryawan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><b>PERHATIAN!!</b></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                Kamu akan menghapus <b>Ahmad Fauza Aulia</b> dari database?
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
                <button type="button" class="btn btn-danger">Hapus</button>
              </div>
            </div>
          </div>
        </div>

        </div>
        <!-- /.container-fluid -->


        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © MANTAP 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Beneran Ingin Keluar?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Pilih "Keluar" jika kamu temenan pengen keluar.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Rak Sido</button>
            <a class="btn btn-primary" href="login.php">Keluar</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>


  </body>

</html>

<?php
if(isset($_POST['update'])){

    $dataNama = $_POST['nama'];
    $dataTtl = $_POST['ttl'];
    $dataAlamat = $_POST['alamat'];
    $dataKelamin = $_POST['kelamin'];
    $dataTelepon = $_POST['telepon'];

$sql = "INSERT INTO tbl_karyawan VALUES ('idkar2','$dataNama','$dataTtl','$dataAlamat','$dataKelamin','$dataTelepon')";
mysqli_query($connect, $sql);
}

?>