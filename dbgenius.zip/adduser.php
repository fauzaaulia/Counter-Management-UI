<?php
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah User</title>
</head>
<body>
    <h1>Tambahkan Karyawan</h1>
    <form method="post" action="adduser.php">
        Username: <br><input type="text" name="username"></br>
        Status: <br><input type="text" name="status"></br>
        Password: <br><input type="text" name="password"></br>
        <button type="submit" name="kirim">kirim!</button>
    </form>    
</body>
</html>

<?php
if(isset($_POST['kirim'])){

    $dataUsername = $_POST['username'];
    $dataStatus = $_POST['status'];
    $dataPassword = $_POST['password'];

$sql = "INSERT INTO tbl_user VALUES ('$dataUsername','$dataStatus','$dataPassword','1234')";
mysqli_query($connect, $sql);
}

?>