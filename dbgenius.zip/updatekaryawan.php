<?php
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah User</title>
</head>
<body>
	<h1>Edit Data Karyawan</h1>
    <form method="post" action="updatekaryawan.php">
        Nama: <br><input type="text" name="nama"></br>
        TTL: <br><input type="text" name="ttl"></br>
        Alamat: <br><input type="text" name="alamat"></br>
        Kelamin: <br><input type="text" name="kelamin"></br>
        Telepon: <br><input type="text" name="telepon"></br>
        <button type="submit" name="update">Update!</button>
    </form>    
</body>
</html>

<?php
if(isset($_POST['update'])){

    $dataNama = $_POST['nama'];
    $dataTtl = $_POST['ttl'];
    $dataAlamat = $_POST['alamat'];
    $dataKelamin = $_POST['kelamin'];
    $dataTelepon = $_POST['telepon'];

$sql = "INSERT INTO tbl_karyawan VALUES ('idkar1','$dataNama','$dataTtl','$dataAlamat','$dataKelamin','$dataTelepon')";
mysqli_query($connect, $sql);
}

?>