<?php
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Masukkan Data</title>
</head>
<body>
	<h1>Masukkan Data Barang</h1>
    <form method="post" action="inputitem.php">
        Nama Barang: <br><input type="text" name="barang"></br>
        Harga Beli: <br><input type="text" name="beli"></br>
        Harga Jual: <br><input type="text" name="jual"></br>
        Stok Barang: <br><input type="text" name="stok"></br>
        Keterangan: <br><input type="text" name="keterangan"></br>
        <button type="submit" name="kirim">kirim!</button>
    </form>    
</body>
</html>

<?php
if(isset($_POST['kirim'])){

    $dataBarang = $_POST['barang'];
    $dataBeli = $_POST['beli'];
    $dataJual = $_POST['jual'];
    $dataStok = $_POST['stok'];
    $dataKet = $_POST['keterangan'];

$sql = "INSERT INTO tbl_barang VALUES ('2245','$dataBarang',$dataBeli,$dataJual,$dataStok,'$dataKet')";
mysqli_query($connect, $sql);
}

?>