<?php
include 'db_connection.php';
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Forgot Password</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body class="bg-dark">

    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Reset Password</div>
        <div class="card-body">
          <div class="text-center mb-4">
            <h4>Kamu Lupa Password?</h4>
            <p>Silahkan Segera hubungi admin sistem ini. Kamu bisa meninggalkan pesan dibawah ini. Admin akan segera mereset password kamu.</p>
          </div>
          <form method="post" action="forgot-password.php">
            <div class="form-group">
              <label class="sr-only" for="inlineFormInputGroup">Username</label>
              <div class="input-group mb-2">
                <div class="input-group-prepend">
                  <div class="input-group-text">@</div>
                </div>
                <input type="text" name="username" class="form-control" id="inlineFormInputGroup" placeholder="Username" required>
              </div>
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1">Nomor Hp</label>
              <input type="text" name="nomorhp" class="form-control" id="exampleFormControlInput1" placeholder="6281215212066">
            </div>            
            <div class="form-group">
              <div class="form-label-group">
                <textarea name="pesan" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Tulis Pesan"></textarea>
              </div>
            </div>
            <button class="btn btn-primary btn-block" name="kirim" type="submit" >Kirim</button>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="login.php">Halaman Masuk</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>

<?php
if(isset($_POST['kirim'])){

    $dataUsername = $_POST['username'];
    $dataPesan = $_POST['pesan'];
    $dataNomorHp = $_POST['nomorhp'];

$sql = "INSERT INTO tbl_pesan VALUES ('$dataUsername','Lupa Password','$dataPesan','$dataNomorHp')";
mysqli_query($connect, $sql);
}

?>